//: Playground - noun: a place where people can play

import UIKit

var saludo: String = "Hola"
var nombre = "Alejandra"

let resultado = saludo + " " + nombre + " " + "Rodriguez"
print(resultado)

var numsix: Int = 6
var numseven: Int = 7
var suma = numsix + numseven
print(suma)

var demo: String = "programación"
var texto = "Esto es \(demo) con swift"

print("Lista de deportes \n1. Basquetball \n2. Soccer")

var x: Int = 34
var y: Int = 5

var mult = x * y

print(mult)

let division = Double (x / y)

var numeroDeVidas = 5

numeroDeVidas++
numeroDeVidas
++numeroDeVidas

numeroDeVidas--
numeroDeVidas
--numeroDeVidas

var dia : Bool = true
var noche : Bool = !dia

let operacion = 300 - 201 * 9 % 6 / 8

let a = 5

var f = 2

let z = 3

print(" Resultado : \( a % ++f * z)")

var contador = 9

contador = contador++

print( contador )



